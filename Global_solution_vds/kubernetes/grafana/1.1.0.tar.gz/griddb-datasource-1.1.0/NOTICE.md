Copyright 2019 TOSHIBA Digital Solutions Corporation
Copyright 2014-2019 Grafana Labs

This software is based on Grafana: 
https://github.com/grafana/grafana

We refered to the Plugin Development Guide and the PLUGIN_DEV.md file for this plugin development.
- the Plugin Development Guide:
    http://docs.grafana.org/plugins/developing/development/
- PLUGIN_DEV.md:
    https://github.com/grafana/grafana/blob/master/PLUGIN_DEV.md
