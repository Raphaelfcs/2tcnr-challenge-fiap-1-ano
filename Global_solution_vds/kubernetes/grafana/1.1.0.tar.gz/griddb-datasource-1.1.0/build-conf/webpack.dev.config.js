module.exports = {
    devtool: 'inline-source-map',
}