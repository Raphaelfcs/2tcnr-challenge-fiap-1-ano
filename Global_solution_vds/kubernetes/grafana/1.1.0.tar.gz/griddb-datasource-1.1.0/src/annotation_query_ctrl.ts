/**
 * Controller object for annotation query view
 *
 * @export
 * @class AnnotationsQueryCtrl
 */
export class AnnotationsQueryCtrl {
    public static templateUrl: string = 'partials/annotations.editor.html';
}
