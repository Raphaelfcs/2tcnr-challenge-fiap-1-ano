rds_instance_name = "rds-lambda-python.czgypqecbnb1.us-east-1.rds.amazonaws.com"
db_username = "admin"
db_password = "12345678"
db_name = "usuarios" 